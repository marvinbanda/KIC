<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="background">
        <div class="container">
            <div class="screen">
                <div class="splash" id="splash"></div> <!-- Only background image here -->
                <div class="login">
                    <div class="login-header">
                        <img class="login-logo" src="https://krisantuswanandi.github.io/alpha/003/logo-dark.svg" alt="Alpha Logo">
                        <div class="login-title">Welcome Back,</div>
                        <div class="login-subtitle">Sign in to continue</div>
                    </div>
                    <div class="login-body">
                        <form class="login-form" id="login-form" method="post">
                            <div class="form-group">
                                <label class="form-label" for="login-email">User name</label>
                                <input class="form-control" type="email" id="login-email" placeholder="example@email.com" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label" for="login-password">Password</label>
                                <input class="form-control" type="password" id="login-password" placeholder="*******" required>
                            </div>
                            <div class="form-group link-forgot-container">
                                <a class="link link-forgot" href="#">Forgot Password?</a>
                            </div>
                            <div class="form-group">
                                <a href="http://13.36.241.255/fish/manager.php">
                                    <button class="login-button" type="button">Financial Records</button>
                                </a>
                            </div>
                            <div class="form-group">
                                <a href="http://13.36.241.255/indexx.php">
                                    <button class="login-button" type="button">Fisheries</button>
                                </a>
                            </div>
                        </form>
                    </div>
                    <div class="login-footer">
                        New user?&nbsp;&nbsp;<a class="link link-register" href="#">Signup</a>
                    </div>
                </div>
            </div>
            <div class="credits">
                developed by
                <a class="credits-link" href="https://dribbble.com/shots/3354720-Login-splash-screen-ZAD-App-iOS" target="_blank">
                    <svg class="dribbble" viewBox="0 0 200 200">
                        <g stroke="#EC4989" fill="none">
                            <circle cx="100" cy="100" r="90" stroke-width="20"></circle>
                            <path d="M62.737004,13.7923523 C105.08055,51.0454853 135.018754,126.906957 141.768278,182.963345" stroke-width="20"></path>
                            <path d="M10.3787186,87.7261455 C41.7092324,90.9577894 125.850356,86.5317271 163.474536,38.7920951" stroke-width="20"></path>
                            <path d="M41.3611549,163.928627 C62.9207607,117.659048 137.020642,86.7137169 189.041451,107.858103" stroke-width="20"></path>
                        </g>
                    </svg>
                    marvin 0757017132
                </a>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
