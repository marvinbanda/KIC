<?php
session_start(); // Start the session

// Hard-coded credentials
$validEmail = 'safi@kic.com';
$validPasswordHash = password_hash('123456789', PASSWORD_BCRYPT);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['login-email'];
    $password = $_POST['login-password'];

    // Validate input
    if (empty($email) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'Email and password are required']);
        exit();
    }

    // Check credentials
    if ($email === $validEmail && password_verify($password, $validPasswordHash)) {
        $_SESSION['user_email'] = $email;
        echo json_encode(['status' => 'success', 'redirect' => 'dashboard.php']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid email or password']);
    }

    exit();
}
?>
