document.addEventListener('DOMContentLoaded', function () {
  var splash = document.getElementById('splash');
  var loginForm = document.getElementById('login-form');
  var loginEmail = document.getElementById('login-email');
  var loginPassword = document.getElementById('login-password');
  var loginEmailParent = loginEmail.parentNode;
  var loginPasswordParent = loginPassword.parentNode;

  loginForm.addEventListener('submit', function (event) {
      event.preventDefault();

      var success = true;
      loginEmailParent.classList.remove('error');
      loginPasswordParent.classList.remove('error');

      if (loginEmail.value.trim() === '') {
          loginEmailParent.classList.add('error');
          success = false;
      }

      if (loginPassword.value === '') {
          loginPasswordParent.classList.add('error');
          success = false;
      }

      if (success) {
          // Perform AJAX request
          var xhr = new XMLHttpRequest();
          xhr.open('POST', 'login.php', true);
          xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
          
          var data = new FormData(loginForm);
          xhr.send(new URLSearchParams(data).toString());

          xhr.onload = function () {
              var response = JSON.parse(xhr.responseText);

              if (response.status === 'success') {
                  splash.classList.add('out');
                  setTimeout(function () {
                      window.location.href = response.redirect; // Redirect to the dashboard or another page
                  }, 500); // Match the duration with CSS transition
              } else {
                  alert(response.message); // Show error message
              }
          };
      }
  });

  // Initial splash screen hide
  setTimeout(function () {
      splash.classList.add('out');
  }, 2000); // Adjust delay as needed
});
